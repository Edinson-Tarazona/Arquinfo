$(document).ready(function(){

	var imgItems= $('.slider li').length;
	var imgPost= 1;

	$('.slider .caption').css({
		opacity: 0,
		top: '-100px'
	});

	$('li .caption').delay(500).animate({
			opacity: 1,
			top: '0px',
			margin: 0 
	}, 1300);


	for(i=1 ; i<= imgItems; i++ ){

		$('.pagination').append('<li><span class="fas fa-circle"></span></li>');
	}



	$('.slider li').hide();//ocultamos las imagenes
	$('.slider li:first').show(); //mostramos la 1er img
	$('.pagination li:first').css({'color':'#CD6E2E'});




	//Ejecutamos todas las funciones

	$('.pagination li').click(pagination);
	$('.right span').click(nextSlider);
	$('.left span').click(prevSlider);


		var timer = null;
	function startSetInterval() {
		    timer = setInterval(function(){
					nextSlider();
					},23000);

	}
	startSetInterval();



	
/*setInterval(function(){
		nextSlider();
	},3000);*/


	
	

	

	// FUNCIONES #########################

	function pagination(){

		$('.slider .caption').css({
		opacity: 0,
		top: '-100px'
		});

		$('.slider .caption2').css({
		opacity: 0,
		left: '-200px'
		});
		
		
		var  paginationPos = $(this).index() +1;
		$('.slider li').hide();
		$('.slider li:nth-child('+ paginationPos +')').fadeIn();
		
		$('.pagination li').css({'color' : 'rgba(0,0,0,.7)'});
		$(this).css({'color':'#CD6E2E'});

		

		imgPost= paginationPos
		$('li .caption').delay(500).animate({
			opacity: 1,
			top: '0px',
			margin: 0 
		}, 1300);

		$('li .caption2').delay(500).animate({
			opacity: 1,
			left: '0px',
			margin: 0 
		}, 1300);




	}


	function nextSlider(){


		$('.slider .caption').css({
		opacity: 0,
		top: '-100px'
		});

		$('.slider .caption2').css({
		opacity: 0,
		left: '-200px'
		});

	
		
		if(imgPost >= imgItems){
			imgPost = 1
		

		}else{
			imgPost ++;
		}
		$('.pagination li').css({'color' : 'rgba(0,0,0,.7)'});/* 858585*/

		$('.pagination li:nth-child('+ imgPost +')').css({'color':'#CD6E2E'});

		$('.slider li').hide();
		$('.slider li:nth-child('+imgPost+')').fadeIn();

		$('li .caption').delay(500).animate({
			opacity: 1,
			top: '0px',
			margin: 0 
		}, 1300);

		$('li .caption2').delay(500).animate({
			opacity: 1,
			left: '0px',
			margin: 0 
		}, 1300);


	}



		function prevSlider(){


		$('.slider .caption').css({
		opacity: 0,
		top: '-100px'
		});

		$('.slider .caption2').css({
		opacity: 0,
		left: '-200px'
		});
		
			

		if(imgPost <= 1){
			imgPost = imgItems

		}else{
			imgPost --;
		}
		$('.pagination li').css({'color' : 'rgba(0,0,0,.7)'});

		$('.pagination li:nth-child('+ imgPost +')').css({'color':'#CD6E2E'});

		$('.slider li').hide();
		$('.slider li:nth-child('+imgPost+')').fadeIn();

		$('li .caption').delay(500).animate({
			opacity: 1,
			top: '0px',
			margin: 0 
		}, 1300);

		$('li .caption2').delay(500).animate({
			opacity: 1,
			left: '0px',
			margin: 0 
		}, 1300);


		

	}



});

