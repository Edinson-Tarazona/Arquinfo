$(document).ready(function(){


	/*	$('.slider .caption').css({
		opacity: 0,
		top: '-200px'
		});

		$('li .caption').animate({
			opacity: 1,
			top: '0px',
			margin: 0 
		}, 3000);*/


	
});